#!/bin/sh
echo $0 $*
progdir=`cd "\`dirname "$0"\`" && pwd`

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$progdir
export PATH=$progdir/bin:$PATH

RA_DIR=/mnt/SDCARD/RetroArch
cd $RA_DIR/

# Run Retroy. Two hand-offs are written by the app into data/:
#   restart  -> after a self-update (OTA), start Retroy again so the new build loads
#   play     -> the launch.sh of a game the user chose to play from the store; run it, then return to the main menu
while :; do
    rm -f "$progdir/data/restart" "$progdir/data/play"
    mkdir -p "$progdir/data"; : > "$progdir/data/ra.log"
    HOME=$RA_DIR/ $RA_DIR/ra64.trimui -v -L $progdir/retroy_libretro.so >> "$progdir/data/ra.log" 2>&1
    if [ -f "$progdir/data/play" ]; then
        game=`head -n 1 "$progdir/data/play"`
        rm -f "$progdir/data/play"
        case "$game" in
            /*/Ports/*/launch.sh|/*/Apps/*/launch.sh) [ -x "$game" ] && "$game" ;;
        esac
        break
    fi
    [ -f "$progdir/data/restart" ] || break
done
