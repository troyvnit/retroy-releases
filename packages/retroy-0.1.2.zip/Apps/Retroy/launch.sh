#!/bin/sh
echo $0 $*
progdir=`cd "\`dirname "$0"\`" && pwd`

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$progdir
export PATH=$progdir/bin:$PATH

RA_DIR=/mnt/SDCARD/RetroArch
cd $RA_DIR/

# Run Retroy. After a self-update (OTA) the app leaves data/restart behind: start again so the new build loads.
while :; do
    rm -f "$progdir/data/restart"
    HOME=$RA_DIR/ $RA_DIR/ra64.trimui -v -L $progdir/retroy_libretro.so
    [ -f "$progdir/data/restart" ] || break
done
