#!/bin/sh
echo $0 $*
progdir=`cd "\`dirname "$0"\`" && pwd`

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$progdir

RA_DIR=/mnt/SDCARD/RetroArch
cd $RA_DIR/

HOME=$RA_DIR/ $RA_DIR/ra64.trimui -v --appendconfig="$progdir/ra-retroy.cfg" -L "$progdir/mrboom_libretro.so"
